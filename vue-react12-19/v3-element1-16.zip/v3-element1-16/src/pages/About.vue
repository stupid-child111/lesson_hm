<template>
    <div>
        关于
    </div>
</template>

<script setup>
console.log('about');
</script>

<style scoped>
</style>