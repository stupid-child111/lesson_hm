<template>
    <el-form 
    style="position: absolute;"
    left: 50%;
    ref="formRef"
    :model="form"
    label-width="auto"
    >

    <el-form-item label="用户名" >
        <el-input v-model="form.username" size="small" />
    </el-form-item>
    <el-form-item label="密码" >
        <el-input v-model="form.password" type="password" size="small" />
    </el-form-item>
    <el-form-item>
    <el-button type="primary" @click="onSubmit" :loading="loading">
        登录
    </el-button>
    </el-form-item>
    </el-form>
    
</template>

<script setup>
import { ref, reactive } from 'vue';
const formRef = ref(null);
//收集表单数据
const form = reactive({
  username: '',
  password: ''  
});
const loading = ref(false);
const onSubmit = async () => {
  loading.value = true;
}
</script>

<style scoped>

</style>